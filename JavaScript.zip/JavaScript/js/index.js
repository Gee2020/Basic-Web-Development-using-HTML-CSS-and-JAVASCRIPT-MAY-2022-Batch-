//Global Var
var first_name = 'Jok', last_name = 'Garcia';

function myFunction() {
    document.getElementById("div1").innerHTML = "Hello! " + first_name;
};

function addNumbers(){
    //Local Var
    var num1, num2, sum;
        
        num1 = 150.70;
        num2 = 200;

        sum = num1 + num2;

        document.getElementById("div-sum").innerHTML = sum.toString() + " " + first_name + ' ' + last_name;
};

function addInputs(n1, n2){
    //Local Var
        var sum;
        sum = n1 + n2;

        document.getElementById("div-sum").innerHTML = sum.toString();
};

function detectTimeAndGreet(){
    
    var hour = new Date().getHours();
    //hour = 'dasda';

    if (hour < 18 ){
        document.getElementById("header").innerHTML = "Good Day!";
    }
    else if(hour > 18){
        document.getElementById("header").innerHTML = "Good Evening!";
    }
    else if(hour > 10 && hour < 12){
        document.getElementById("header").innerHTML = "Lunch Time!!" + "it is " + hour;
    }
    else{
        document.getElementById("header").innerHTML = "Invalid Hour";
    }
};


function subtractNumbers(){
    var n1 = document.getElementById("input1").value; 
    var n2 = document.getElementById("input2").value;

    var diff = n1 - n2;

    document.getElementById("div-diff").innerHTML = "Difference is : " + diff.toString();
}