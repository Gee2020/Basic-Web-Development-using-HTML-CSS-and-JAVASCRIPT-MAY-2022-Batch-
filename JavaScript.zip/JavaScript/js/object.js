//properties: value



var product = { 
                  code: "001", 
                  product_name: "Samsung", 
                  category: "Mobile", 
                  price: 400.50,
                  tax: 300.50,
                  selling_price: function (){
                    return this.price + this.tax
                  }
                };

const customer = {id: "1", full_name: "Jok Garcia", contact: "32323232"};

//Array - same Data Type -starts with index 0
const countries = ["Philippines","USA","Japan"];


function getOrder(){
    var fullname = document.getElementById("fullname").value;

    //
    
    var prod_name = document.getElementById("product").value;
    var price = document.getElementById("price").value;
    var tax = document.getElementById("tax").value;

    var shipping_fee = 40.99;
    price = arseFloat(price) + arseFloat(shipping_fee);

    product.product_name = prod_name;
    product.price = parseFloat(price);
    product.tax = parseFloat(tax);

    //var order = new product("003",prod_name,"Mobile",price,tax);
        
    document.getElementById("div-order").innerHTML = "Hi! " + fullname + " " + " your order is " + product.product_name + " selling price :" + product.selling_price();
    //document.write("Hi! " + fullname + " " + " your order is " + product.product_name + " price :" + product.price)
};

function showCountry(){
    document.getElementById("div-country").innerHTML = "Country : " + countries[1];
};

